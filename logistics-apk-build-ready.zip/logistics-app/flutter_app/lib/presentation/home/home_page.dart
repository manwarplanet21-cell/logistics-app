import 'package:flutter/material.dart';
import '../../core/app_config.dart';
import '../../core/app_theme.dart';
import '../customer/tracking_page.dart';
import '../driver/driver_simulator_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final TextEditingController _serverController = TextEditingController(
    text: AppConfig.defaultServerUrl,
  );
  final TextEditingController _driverIdController = TextEditingController(text: '1');

  @override
  void dispose() {
    _serverController.dispose();
    _driverIdController.dispose();
    super.dispose();
  }

  void _openDriverMode() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => Directionality(
          textDirection: TextDirection.rtl,
          child: DriverSimulatorPage(
            serverUrl: _serverController.text.trim(),
            driverId: _driverIdController.text.trim(),
          ),
        ),
      ),
    );
  }

  void _openCustomerMode() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => Directionality(
          textDirection: TextDirection.rtl,
          child: DriverTrackingPage(
            serverUrl: _serverController.text.trim(),
            driverId: _driverIdController.text.trim(),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Container(
                padding: const EdgeInsets.all(22),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [AppTheme.primary, Color(0xFF0B2545)],
                    begin: Alignment.topRight,
                    end: Alignment.bottomLeft,
                  ),
                  borderRadius: BorderRadius.circular(24),
                  boxShadow: const [
                    BoxShadow(
                      color: Color(0x33153E75),
                      blurRadius: 20,
                      offset: Offset(0, 12),
                    )
                  ],
                ),
                child: const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(Icons.local_shipping_rounded, color: Colors.white, size: 42),
                    SizedBox(height: 16),
                    Text(
                      'Logistics Tracking',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 26,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    SizedBox(height: 8),
                    Text(
                      'تطبيق تجريبي احترافي لتتبع السائق لحظياً على أندرويد باستخدام Flutter و Socket.IO.',
                      style: TextStyle(color: Color(0xFFE8EEF8), fontSize: 14, height: 1.5),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),
              TextField(
                controller: _serverController,
                textDirection: TextDirection.ltr,
                decoration: const InputDecoration(
                  labelText: 'رابط السيرفر',
                  hintText: 'http://10.0.2.2:3000',
                  prefixIcon: Icon(Icons.dns_rounded),
                ),
              ),
              const SizedBox(height: 14),
              TextField(
                controller: _driverIdController,
                keyboardType: TextInputType.number,
                textDirection: TextDirection.ltr,
                decoration: const InputDecoration(
                  labelText: 'رقم السائق',
                  prefixIcon: Icon(Icons.badge_rounded),
                ),
              ),
              const SizedBox(height: 22),
              FilledButton.icon(
                onPressed: _openDriverMode,
                icon: const Icon(Icons.navigation_rounded),
                label: const Text('فتح وضع السائق وإرسال الموقع'),
              ),
              const SizedBox(height: 12),
              OutlinedButton.icon(
                onPressed: _openCustomerMode,
                icon: const Icon(Icons.map_rounded),
                label: const Text('فتح وضع العميل وتتبع الشحنة'),
              ),
              const SizedBox(height: 18),
              const _InfoCard(
                title: 'ملاحظات التشغيل على أندرويد',
                text: 'عند استخدام Android Emulator استخدم 10.0.2.2 بدل localhost. عند استخدام هاتف حقيقي استخدم IP جهاز الكمبيوتر على نفس شبكة Wi-Fi.',
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _InfoCard extends StatelessWidget {
  final String title;
  final String text;
  const _InfoCard({required this.title, required this.text});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Icon(Icons.info_outline_rounded, color: AppTheme.secondary),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
                  const SizedBox(height: 6),
                  Text(text, style: const TextStyle(height: 1.45, color: Color(0xFF5E6A7D))),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
