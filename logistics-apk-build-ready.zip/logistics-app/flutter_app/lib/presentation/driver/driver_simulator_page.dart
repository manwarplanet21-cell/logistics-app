import 'dart:async';
import 'package:flutter/material.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;
import '../../core/app_theme.dart';

class DriverSimulatorPage extends StatefulWidget {
  final String serverUrl;
  final String driverId;

  const DriverSimulatorPage({
    super.key,
    required this.serverUrl,
    required this.driverId,
  });

  @override
  State<DriverSimulatorPage> createState() => _DriverSimulatorPageState();
}

class _DriverSimulatorPageState extends State<DriverSimulatorPage> {
  late IO.Socket _socket;
  Timer? _timer;
  bool _connected = false;
  bool _sending = false;

  double _lat = 15.5881;
  double _lng = 32.5342;
  int _sentCount = 0;

  @override
  void initState() {
    super.initState();
    _socket = IO.io(
      widget.serverUrl,
      IO.OptionBuilder()
          .setTransports(['websocket'])
          .enableReconnection()
          .setReconnectionAttempts(100)
          .setReconnectionDelay(1200)
          .disableAutoConnect()
          .build(),
    );

    _socket.onConnect((_) {
      if (mounted) setState(() => _connected = true);
      _socket.emit('driver_online', widget.driverId);
    });

    _socket.onDisconnect((_) {
      if (mounted) setState(() => _connected = false);
    });

    _socket.connect();
  }

  void _toggleSending() {
    if (_sending) {
      _timer?.cancel();
      setState(() => _sending = false);
      return;
    }

    setState(() => _sending = true);
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      _lat += 0.00015;
      _lng += 0.00010;
      _sentCount++;
      _socket.emit('update_location', {
        'driverId': widget.driverId,
        'lat': _lat,
        'lng': _lng,
      });
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _socket.disconnect();
    _socket.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('وضع السائق')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(18),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          width: 56,
                          height: 56,
                          decoration: BoxDecoration(
                            color: AppTheme.secondary.withOpacity(0.12),
                            borderRadius: BorderRadius.circular(18),
                          ),
                          child: const Icon(Icons.navigation_rounded, color: AppTheme.secondary, size: 32),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('السائق رقم ${widget.driverId}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                              const SizedBox(height: 4),
                              Text(_connected ? 'متصل وجاهز للإرسال' : 'بانتظار الاتصال بالسيرفر', style: const TextStyle(color: Color(0xFF6B7280))),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 18),
                    _MetricRow(label: 'خط العرض', value: _lat.toStringAsFixed(6)),
                    _MetricRow(label: 'خط الطول', value: _lng.toStringAsFixed(6)),
                    _MetricRow(label: 'عدد التحديثات المرسلة', value: '$_sentCount'),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),
            FilledButton.icon(
              onPressed: _connected ? _toggleSending : null,
              icon: Icon(_sending ? Icons.stop_rounded : Icons.play_arrow_rounded),
              label: Text(_sending ? 'إيقاف إرسال الموقع' : 'بدء إرسال الموقع كل ثانية'),
            ),
            const SizedBox(height: 12),
            const Text(
              'هذه الصفحة تحاكي حركة السائق لأغراض التجربة. في النسخة الإنتاجية يتم استبدال المحاكاة بموقع GPS الحقيقي من الهاتف.',
              style: TextStyle(color: Color(0xFF6B7280), height: 1.45),
            ),
          ],
        ),
      ),
    );
  }
}

class _MetricRow extends StatelessWidget {
  final String label;
  final String value;
  const _MetricRow({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 10),
      child: Row(
        children: [
          Expanded(child: Text(label, style: const TextStyle(color: Color(0xFF6B7280)))),
          Text(value, textDirection: TextDirection.ltr, style: const TextStyle(fontWeight: FontWeight.w800)),
        ],
      ),
    );
  }
}
