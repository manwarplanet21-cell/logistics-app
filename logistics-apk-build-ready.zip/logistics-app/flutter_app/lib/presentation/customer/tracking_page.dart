import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;
import '../../core/app_theme.dart';

class DriverTrackingPage extends StatefulWidget {
  final String serverUrl;
  final String driverId;

  const DriverTrackingPage({
    super.key,
    required this.serverUrl,
    required this.driverId,
  });

  @override
  State<DriverTrackingPage> createState() => _DriverTrackingPageState();
}

class _DriverTrackingPageState extends State<DriverTrackingPage> {
  GoogleMapController? _mapController;
  late IO.Socket _socket;

  LatLng _currentDriverLocation = const LatLng(15.5881, 32.5342);
  Set<Marker> _markers = {};
  bool _connected = false;
  DateTime? _lastUpdate;

  @override
  void initState() {
    super.initState();
    _updateDriverMarker(_currentDriverLocation);
    _initWebSocket();
  }

  void _initWebSocket() {
    _socket = IO.io(
      widget.serverUrl,
      IO.OptionBuilder()
          .setTransports(['websocket'])
          .enableReconnection()
          .setReconnectionAttempts(100)
          .setReconnectionDelay(1200)
          .disableAutoConnect()
          .build(),
    );

    _socket.onConnect((_) {
      if (mounted) setState(() => _connected = true);
      _socket.emit('join_tracking_room', widget.driverId);
    });

    _socket.onDisconnect((_) {
      if (mounted) setState(() => _connected = false);
    });

    _socket.on('driver_location_updated', (data) {
      if (data == null || !mounted) return;
      final lat = data['lat'];
      final lng = data['lng'];
      if (lat == null || lng == null) return;

      final newPosition = LatLng((lat as num).toDouble(), (lng as num).toDouble());

      setState(() {
        _currentDriverLocation = newPosition;
        _lastUpdate = DateTime.now();
        _updateDriverMarker(newPosition);
      });

      _mapController?.animateCamera(CameraUpdate.newLatLng(newPosition));
    });

    _socket.connect();
  }

  void _updateDriverMarker(LatLng position) {
    _markers = {
      Marker(
        markerId: const MarkerId('driver_vehicle'),
        position: position,
        icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueAzure),
        infoWindow: const InfoWindow(title: 'مندوب التوصيل في الطريق إليك'),
      ),
    };
  }

  @override
  void dispose() {
    _socket.disconnect();
    _socket.dispose();
    _mapController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final lastUpdateText = _lastUpdate == null
        ? 'لم يتم استقبال موقع جديد بعد'
        : 'آخر تحديث: ${_lastUpdate!.hour.toString().padLeft(2, '0')}:${_lastUpdate!.minute.toString().padLeft(2, '0')}:${_lastUpdate!.second.toString().padLeft(2, '0')}';

    return Scaffold(
      appBar: AppBar(title: const Text('تتبع الشحنة لحظياً')),
      body: Stack(
        children: [
          GoogleMap(
            initialCameraPosition: CameraPosition(target: _currentDriverLocation, zoom: 14.5),
            markers: _markers,
            myLocationButtonEnabled: true,
            zoomControlsEnabled: false,
            mapToolbarEnabled: false,
            onMapCreated: (controller) => _mapController = controller,
          ),
          Positioned(
            top: 14,
            left: 16,
            right: 16,
            child: _StatusPill(connected: _connected),
          ),
          Positioned(
            bottom: 20,
            left: 16,
            right: 16,
            child: Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    Container(
                      width: 52,
                      height: 52,
                      decoration: BoxDecoration(
                        color: AppTheme.primary.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: const Icon(Icons.local_shipping_rounded, color: AppTheme.primary, size: 30),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Text('جاري توصيل شحنتك', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                          const SizedBox(height: 4),
                          Text(lastUpdateText, style: const TextStyle(color: Color(0xFF6B7280), fontSize: 12)),
                          const SizedBox(height: 4),
                          Text(
                            'Lat ${_currentDriverLocation.latitude.toStringAsFixed(5)} / Lng ${_currentDriverLocation.longitude.toStringAsFixed(5)}',
                            textDirection: TextDirection.ltr,
                            style: const TextStyle(color: Color(0xFF6B7280), fontSize: 11),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _StatusPill extends StatelessWidget {
  final bool connected;
  const _StatusPill({required this.connected});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              connected ? Icons.wifi_rounded : Icons.wifi_off_rounded,
              color: connected ? AppTheme.secondary : Colors.redAccent,
            ),
            const SizedBox(width: 8),
            Text(
              connected ? 'متصل بالسيرفر' : 'غير متصل بالسيرفر',
              style: const TextStyle(fontWeight: FontWeight.w700),
            ),
          ],
        ),
      ),
    );
  }
}
