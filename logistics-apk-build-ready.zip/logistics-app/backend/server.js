const express = require('express');
const http = require('http');
const cors = require('cors');
const helmet = require('helmet');
const { Server } = require('socket.io');
require('dotenv').config();

const sequelize = require('./config/database');
const Driver = require('./models/Driver');
const dispatchRoutes = require('./routes/dispatchRoutes');
const { updateDriverLocation } = require('./services/dispatchService');

const app = express();

app.use(cors({ origin: process.env.FRONTEND_ORIGIN || '*' }));
app.use(helmet());
app.use(express.json());

const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: process.env.FRONTEND_ORIGIN || '*',
    methods: ['GET', 'POST'],
  },
});

const activeDrivers = new Map();

io.on('connection', (socket) => {
  console.log(`New connection: ${socket.id}`);

  socket.on('driver_online', async (driverId) => {
    socket.join('drivers_room');
    activeDrivers.set(String(driverId), { socketId: socket.id, lat: null, lng: null });
    await Driver.update({ isAvailable: true }, { where: { id: driverId } });
    console.log(`Driver ${driverId} is online`);
  });

  socket.on('join_tracking_room', (driverId) => {
    socket.join(`track_driver_${driverId}`);
    console.log(`Customer joined tracking room for driver ${driverId}`);
  });

  socket.on('update_location', async (data) => {
    const { driverId, lat, lng } = data || {};
    if (!driverId || lat == null || lng == null) return;

    if (activeDrivers.has(String(driverId))) {
      const driverInfo = activeDrivers.get(String(driverId));
      driverInfo.lat = lat;
      driverInfo.lng = lng;
      activeDrivers.set(String(driverId), driverInfo);

      await updateDriverLocation(driverId, lat, lng);

      io.to(`track_driver_${driverId}`).emit('driver_location_updated', {
        driverId,
        lat,
        lng,
      });
    }
  });

  socket.on('disconnect', async () => {
    for (const [driverId, value] of activeDrivers.entries()) {
      if (value.socketId === socket.id) {
        activeDrivers.delete(driverId);
        await Driver.update({ isAvailable: false }, { where: { id: driverId } });
        console.log(`Driver ${driverId} disconnected`);
        break;
      }
    }
  });
});

app.use('/api/dispatch', dispatchRoutes);

app.get('/health', (req, res) => {
  res.json({ status: 'running', time: new Date(), activeDrivers: activeDrivers.size });
});

const PORT = process.env.PORT || 3000;

async function startServer() {
  try {
    await sequelize.authenticate();
    await sequelize.query('CREATE EXTENSION IF NOT EXISTS postgis;');
    await sequelize.sync({ alter: true });
    server.listen(PORT, () => console.log(`Logistics server running on port ${PORT}`));
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();

module.exports = { io, activeDrivers };
