const express = require('express');
const router = express.Router();
const Driver = require('../models/Driver');
const { findNearestDriver } = require('../services/dispatchService');

router.post('/drivers', async (req, res) => {
  try {
    const { name, phone, lat, lng } = req.body;
    if (!name) {
      return res.status(400).json({ success: false, message: 'name is required' });
    }

    const payload = { name, phone, isAvailable: true };
    if (lat != null && lng != null) {
      payload.location = { type: 'Point', coordinates: [lng, lat] };
    }

    const driver = await Driver.create(payload);
    return res.status(201).json({ success: true, driver });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
});

router.get('/drivers', async (req, res) => {
  try {
    const drivers = await Driver.findAll({ order: [['id', 'ASC']] });
    return res.json({ success: true, drivers });
  } catch (error) {
    return res.status(500).json({ success: false, message: error.message });
  }
});

router.post('/nearest-driver', async (req, res) => {
  const { pickupLat, pickupLng, maxDistanceMeters } = req.body;

  if (pickupLat == null || pickupLng == null) {
    return res.status(400).json({
      success: false,
      message: 'pickupLat and pickupLng are required',
    });
  }

  const driver = await findNearestDriver(
    Number(pickupLat),
    Number(pickupLng),
    Number(maxDistanceMeters || 5000)
  );

  if (!driver) {
    return res.json({
      success: false,
      message: 'No available driver found nearby',
      driver: null,
    });
  }

  return res.json({ success: true, driver });
});

module.exports = router;
