# بناء ملف APK مباشرة

## الطريقة الأولى: GitHub Actions

1. أنشئ Repository جديدًا في GitHub.
2. ارفع محتويات مجلد `logistics-app` بالكامل.
3. من Settings > Secrets and variables > Actions أضف الأسرار التالية:
   - `GOOGLE_MAPS_API_KEY`
   - `SERVER_URL`
4. افتح تبويب Actions.
5. شغّل Workflow باسم `Build Android APK`.
6. بعد اكتمال البناء، ستجد ملف APK داخل Artifacts باسم:
   `logistics-tracking-release-apk`

اسم ملف APK الناتج:

```txt
logistics-tracking-release.apk
```

## الطريقة الثانية: Codemagic

1. اربط المشروع مع Codemagic.
2. سيقرأ ملف `codemagic.yaml` تلقائيًا.
3. أضف المتغيرات:
   - `GOOGLE_MAPS_API_KEY`
   - `SERVER_URL`
4. شغّل Workflow باسم `android-release-apk`.
5. حمّل APK من قسم Artifacts.

## ملاحظات مهمة

- لا تضع مفاتيح Google Maps أو كلمات مرور قاعدة البيانات داخل الكود.
- أثناء تجربة Android Emulator استخدم:

```txt
http://10.0.2.2:3000
```

- أثناء تجربة هاتف حقيقي، استخدم IP جهاز السيرفر داخل نفس الشبكة مثل:

```txt
http://192.168.1.20:3000
```
