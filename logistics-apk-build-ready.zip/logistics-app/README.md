# Logistics Tracking App

مشروع تجريبي احترافي لتطبيق تتبع شحنات لحظي يعمل على Android باستخدام Flutter، مع Backend مبني بـ Node.js + Socket.IO + PostgreSQL/PostGIS.

## محتويات المشروع

- `backend/`: السيرفر وواجهات API وخدمة البحث عن أقرب سائق.
- `flutter_app/`: تطبيق Android/Flutter للعميل والسائق.
- `.github/workflows/build-apk.yml`: بناء APK تلقائيًا عبر GitHub Actions.
- `codemagic.yaml`: بناء APK عبر Codemagic.
- `APK_BUILD_GUIDE_AR.md`: شرح عربي مختصر لاستخراج APK.

## تشغيل Backend

```bash
cd backend
cp .env.example .env
npm install
npm run dev
```

اختبار السيرفر:

```txt
http://localhost:3000/health
```

## تشغيل Flutter محليًا

```bash
cd flutter_app
flutter pub get
flutter run --dart-define=SERVER_URL=http://10.0.2.2:3000
```

## بناء APK محليًا

```bash
cd flutter_app
flutter build apk --release --dart-define=SERVER_URL=http://YOUR_SERVER_IP:3000 --no-tree-shake-icons
```

المخرج سيكون في:

```txt
flutter_app/build/app/outputs/flutter-apk/app-release.apk
```

## بناء APK تلقائيًا

تمت إضافة GitHub Actions وCodemagic. راجع الملف:

```txt
APK_BUILD_GUIDE_AR.md
```

## تنبيه أمني

يجب تغيير أي كلمة مرور أو API Key ظهرت في المحادثة، ولا تستخدمها في الإنتاج.
